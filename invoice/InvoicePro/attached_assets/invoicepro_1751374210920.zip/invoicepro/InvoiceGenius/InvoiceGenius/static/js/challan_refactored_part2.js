const selectAllCheckbox = document.getElementById('selectAllChallans');
    const challanCheckboxes = document.querySelectorAll('.challanCheckbox');
    const generateBtn = document.getElementById('generateConsolidatedInvoiceBtn');
    const consolidatedModal = new bootstrap.Modal(document.getElementById('consolidatedInvoiceModal'));
    const confirmConsolidatedBtn = document.getElementById('confirmConsolidatedInvoiceBtn');

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            challanCheckboxes.forEach(chk => {
                if (!chk.disabled) {
                    chk.checked = selectAllCheckbox.checked;
                }
            });
            debounceUpdateGenerateButtonState();
        });
    }

    challanCheckboxes.forEach(chk => {
        chk.addEventListener('change', function() {
            debounceUpdateGenerateButtonState();
            if (!this.checked && selectAllCheckbox) {
                selectAllCheckbox.checked = false;
            }
        });
    });

    if (generateBtn) {
        generateBtn.addEventListener('click', function() {
            consolidatedModal.show();
        });
    }

    if (confirmConsolidatedBtn) {
        confirmConsolidatedBtn.addEventListener('click', function() {
            const selectedChallans = Array.from(challanCheckboxes)
                .filter(chk => chk.checked)
                .map(chk => chk.getAttribute('data-challan-id'));

            const consolidationOption = document.querySelector('input[name="consolidationOption"]:checked').value;
            const dueDate = document.getElementById('consolidatedDueDate').value;
            const notes = document.getElementById('consolidatedNotes').value;

            if (selectedChallans.length === 0) {
                alert('Please select at least one challan.');
                return;
            }

            let url = `${window.location.origin}/convert_multiple_challans_to_invoice?challan_ids=${selectedChallans.join(',')}&consolidation_option=${consolidationOption}`;
            if (dueDate) url += `&due_date=${dueDate}`;
            if (notes) url += `&notes=${encodeURIComponent(notes)}`;

            window.location.href = url;
        });
    }
}

// Debounce updateGenerateButtonState to reduce flickering
function debounceUpdateGenerateButtonState() {
    clearTimeout(updateGenerateButtonTimeout);
    updateGenerateButtonTimeout = setTimeout(updateGenerateButtonState, 200);
}

// Update the state of the Generate Consolidated Invoice button
function updateGenerateButtonState() {
    const challanCheckboxes = document.querySelectorAll('.challanCheckbox');
    const generateBtn = document.getElementById('generateConsolidatedInvoiceBtn');
    const anyChecked = Array.from(challanCheckboxes).some(chk => chk.checked);
    if (generateBtn) {
        generateBtn.disabled = !anyChecked;
    }
}

// Handle client selection with minimal DOM updates
function handleChallanClientSelection(event) {
    const selectedOption = event.target.options[event.target.selectedIndex];
    const clientDetails = document.getElementById('clientDetails');

    if (selectedOption.value) {
        if (clientDetails.dataset.currentClient !== selectedOption.value) {
            document.getElementById('clientAddress').textContent = selectedOption.dataset.address || 'N/A';
            document.getElementById('clientCity').textContent = selectedOption.dataset.city || 'N/A';
            document.getElementById('clientState').textContent = selectedOption.dataset.state || 'N/A';
            document.getElementById('clientPhone').textContent = selectedOption.dataset.phone || 'N/A';

            clientDetails.classList.remove('d-none');
            clientDetails.dataset.currentClient = selectedOption.value;

            selectedClient = {
                id: selectedOption.value,
                name: selectedOption.dataset.name,
                state: selectedOption.dataset.state
            };

            loadClientInvoicesForImport(selectedOption.value);
        }
    } else {
        clientDetails.classList.add('d-none');
        clientDetails.dataset.currentClient = '';
        selectedClient = null;
    }
}

// Update delivery date based on challan date
function updateDeliveryDate() {
    const challanDateInput = document.getElementById('challan_date');
    const deliveryDateInput = document.getElementById('delivery_date');

    if (challanDateInput.value && deliveryDateInput && !deliveryDateInput.value) {
        const deliveryDate = new Date(challanDateInput.value);
        deliveryDate.setDate(deliveryDate.getDate() + 1);
        deliveryDateInput.value = deliveryDate.toISOString().split('T')[0];
    }
}

// Calculate challan totals with debouncing
function calculateChallanTotals() {
    clearTimeout(calculateTotalsTimeout);
    calculateTotalsTimeout = setTimeout(() => {
        let totalQuantity = 0;
        let totalValue = 0;

        const rows = document.querySelectorAll('#challanItemsBody tr');

        rows.forEach(row => {
            const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
            const price = parseFloat(row.querySelector('.price-input').value) || 0;
            const lineTotal = qty * price;

            row.querySelector('.total-cell').textContent = `₹${lineTotal.toFixed(2)}`;

            totalQuantity += qty;
            totalValue += lineTotal;
        });

        document.getElementById('totalQuantity').textContent = totalQuantity.toFixed(2);
        document.getElementById('totalValue').textContent = `₹${totalValue.toFixed(2)}`;
    }, 150);
}

// Other functions (addChallanItem, removeChallanItem, etc.) remain unchanged and can be added here as needed

// Export functions globally if needed
window.ChallanForm = {
    initializeChallanForm,
    setupEventListeners,
    handleChallanClientSelection,
    updateDeliveryDate,
    calculateChallanTotals,
    debounceUpdateGenerateButtonState,
    updateGenerateButtonState
};
</create_file>
