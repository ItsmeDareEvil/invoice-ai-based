// Delivery Challan Management JavaScript

// Global variables
let challanItemCounter = 0;
let challanItems = [];
let selectedClient = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeChallanForm();
    //setupChallanEventListeners();
});

// Initialize challan form
function initializeChallanForm() {
    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    const challanDateInput = document.getElementById('challan_date');
    const deliveryDateInput = document.getElementById('delivery_date');
    
    if (challanDateInput && !challanDateInput.value) {
        challanDateInput.value = today;
    }
    
    // Set default delivery date (next day)
    if (deliveryDateInput && !deliveryDateInput.value && challanDateInput.value) {
        const deliveryDate = new Date(challanDateInput.value);
        deliveryDate.setDate(deliveryDate.getDate() + 1);
        deliveryDateInput.value = deliveryDate.toISOString().split('T')[0];
    }
    
    // Setup client autocomplete
    setupChallanClientAutocomplete();
}

// Setup event listeners
let updateGenerateButtonTimeout;

function updateGenerateButtonState() {
    console.log('updateGenerateButtonState called');
    clearTimeout(updateGenerateButtonTimeout);
    updateGenerateButtonTimeout = setTimeout(() => {
        var anyChecked = false;
        var challanCheckboxes = document.querySelectorAll('.challanCheckbox');
        for (var i = 0; i < challanCheckboxes.length; i++) {
            if (challanCheckboxes[i].checked) {
                anyChecked = true;
                break;
            }
        }
        var generateBtn = document.getElementById('generateConsolidatedInvoiceBtn');
        if (generateBtn) {
            generateBtn.disabled = !anyChecked;
        }
    }, 200);
}

document.addEventListener('DOMContentLoaded', function() {
    var selectAllCheckbox = document.getElementById('selectAllChallans');
    var challanCheckboxes = document.querySelectorAll('.challanCheckbox');
    var generateBtn = document.getElementById('generateConsolidatedInvoiceBtn');
    var consolidatedModal = new bootstrap.Modal(document.getElementById('consolidatedInvoiceModal'));
    var confirmConsolidatedBtn = document.getElementById('confirmConsolidatedInvoiceBtn');

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            for (var i = 0; i < challanCheckboxes.length; i++) {
                if (!challanCheckboxes[i].disabled) {
                    challanCheckboxes[i].checked = selectAllCheckbox.checked;
                }
            }
            updateGenerateButtonState();
        });
    }

    for (var i = 0; i < challanCheckboxes.length; i++) {
        challanCheckboxes[i].addEventListener('change', function() {
            updateGenerateButtonState();
            if (!this.checked) {
                selectAllCheckbox.checked = false;
            }
        });
    }

    generateBtn.addEventListener('click', function() {
        consolidatedModal.show();
    });

    confirmConsolidatedBtn.addEventListener('click', function() {
        var selectedChallans = [];
        for (var i = 0; i < challanCheckboxes.length; i++) {
            if (challanCheckboxes[i].checked) {
                selectedChallans.push(challanCheckboxes[i].getAttribute('data-challan-id'));
            }
        }
        var consolidationOption = document.querySelector('input[name="consolidationOption"]:checked').value;
        var dueDate = document.getElementById('consolidatedDueDate').value;
        var notes = document.getElementById('consolidatedNotes').value;

        console.log('Selected Challans:', selectedChallans);
        console.log('Consolidation Option:', consolidationOption);
        console.log('Due Date:', dueDate);
        console.log('Notes:', notes);

        if (selectedChallans.length === 0) {
            alert('Please select at least one challan.');
            return;
        }

        var url = window.location.origin + '/convert_multiple_challans_to_invoice?challan_ids=' + selectedChallans.join(',') + '&consolidation_option=' + consolidationOption;
        if (dueDate) {
            url += '&due_date=' + dueDate;
        }
        if (notes) {
            url += '&notes=' + encodeURIComponent(notes);
        }

        window.location.href = url;
    });
});

// Handle client selection
function handleChallanClientSelection(event) {
    const selectedOption = event.target.options[event.target.selectedIndex];
    const clientDetails = document.getElementById('clientDetails');
    
    if (selectedOption.value) {
        // Populate client details only if changed to reduce flickering
        if (clientDetails.dataset.currentClient !== selectedOption.value) {
            document.getElementById('clientAddress').textContent = selectedOption.dataset.address || 'N/A';
            document.getElementById('clientCity').textContent = selectedOption.dataset.city || 'N/A';
            document.getElementById('clientState').textContent = selectedOption.dataset.state || 'N/A';
            document.getElementById('clientPhone').textContent = selectedOption.dataset.phone || 'N/A';
            
            clientDetails.classList.remove('d-none');
            clientDetails.dataset.currentClient = selectedOption.value;
            
            // Store selected client data
            selectedClient = {
                id: selectedOption.value,
                name: selectedOption.dataset.name,
                state: selectedOption.dataset.state
            };
            
            // Load client invoices for import option
            loadClientInvoicesForImport(selectedOption.value);
        }
    } else {
        clientDetails.classList.add('d-none');
        clientDetails.dataset.currentClient = '';
        selectedClient = null;
    }
}

// Update delivery date based on challan date
function updateDeliveryDate() {
    const challanDateInput = document.getElementById('challan_date');
    const deliveryDateInput = document.getElementById('delivery_date');
    
    if (challanDateInput.value && deliveryDateInput && !deliveryDateInput.value) {
        const deliveryDate = new Date(challanDateInput.value);
        deliveryDate.setDate(deliveryDate.getDate() + 1);
        deliveryDateInput.value = deliveryDate.toISOString().split('T')[0];
    }
}

// Add challan item
function addChallanItem() {
    challanItemCounter++;
    const tbody = document.getElementById('challanItemsBody');
    const row = document.createElement('tr');
    row.className = 'challan-item-row';
    row.innerHTML = `
        <td>${challanItemCounter}</td>
        <td>
            <input type="text" class="form-control form-control-sm hsn-input" 
                   placeholder="HSN Code" data-bs-toggle="tooltip" title="Harmonized System of Nomenclature Code">
        </td>
        <td>
            <input type="text" class="form-control form-control-sm desc-input" 
                   placeholder="Item description" required>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm qty-input" 
                   step="0.01" min="0" placeholder="1" required>
        </td>
        <td>
            <select class="form-select form-select-sm unit-input">
                <option value="Nos">Nos</option>
                <option value="Kg">Kg</option>
                <option value="Ltr">Ltr</option>
                <option value="Mtr">Mtr</option>
                <option value="Ft">Ft</option>
                <option value="Box">Box</option>
                <option value="Set">Set</option>
                <option value="Pair">Pair</option>
                <option value="Pcs">Pcs</option>
            </select>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm price-input" 
                   step="0.01" min="0" placeholder="0.00">
        </td>
        <td class="total-cell text-end">₹0.00</td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeChallanItem(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    // Add event listeners to new row
    setupChallanItemEventListeners(row);
    
    // Initialize tooltips for new elements
    const tooltips = row.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(element => {
        new bootstrap.Tooltip(element);
    });
    
    // Focus on description input
    row.querySelector('.desc-input').focus();
    
    // Update totals
    calculateChallanTotals();
}

// Setup event listeners for challan item row
function setupChallanItemEventListeners(row) {
    const qtyInput = row.querySelector('.qty-input');
    const priceInput = row.querySelector('.price-input');
    
    [qtyInput, priceInput].forEach(input => {
        // Debounce the calculateChallanTotals to reduce frequent calls causing flickering
        let debounceTimeout;
        input.addEventListener('input', () => {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(calculateChallanTotals, 200);
        });
        input.addEventListener('blur', calculateChallanTotals);
    });
    
    // HSN code autocomplete
    const hsnInput = row.querySelector('.hsn-input');
    hsnInput.addEventListener('input', function() {
        if (this.value.length >= 4) {
            // Could implement HSN code validation here
        }
    });
    
    // Description autocomplete with product suggestions
    const descInput = row.querySelector('.desc-input');
    descInput.addEventListener('input', function() {
        // Could implement product description suggestions here
        debounceProductSuggestions(this.value);
    });
}

// Remove challan item
function removeChallanItem(button) {
    const row = button.closest('tr');
    row.remove();
    calculateChallanTotals();
    renumberChallanItems();
}

// Renumber challan items
function renumberChallanItems() {
    const rows = document.querySelectorAll('#challanItemsBody tr');
    rows.forEach((row, index) => {
        row.querySelector('td:first-child').textContent = index + 1;
    });
    challanItemCounter = rows.length;
}

// Calculate challan totals
function calculateChallanTotals() {
    let totalQuantity = 0;
    let totalValue = 0;
    
    const rows = document.querySelectorAll('#challanItemsBody tr');
    
    rows.forEach(row => {
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        const lineTotal = qty * price;
        
        // Update line total display
        row.querySelector('.total-cell').textContent = `₹${lineTotal.toFixed(2)}`;
        
        totalQuantity += qty;
        totalValue += lineTotal;
    });
    
    // Update display
    document.getElementById('totalQuantity').textContent = totalQuantity.toFixed(2);
    document.getElementById('totalValue').textContent = `₹${totalValue.toFixed(2)}`;
}

// Handle form submission
function handleChallanFormSubmission(event) {
    event.preventDefault();
    
    // Validate form
    if (!validateChallanForm()) {
        return false;
    }
    
    // Collect line items data
    const items = [];
    const rows = document.querySelectorAll('#challanItemsBody tr');
    
    rows.forEach((row, index) => {
        const item = {
            sr_no: index + 1,
            hsn_code: row.querySelector('.hsn-input').value,
            description: row.querySelector('.desc-input').value,
            quantity: parseFloat(row.querySelector('.qty-input').value) || 0,
            unit: row.querySelector('.unit-input').value,
            unit_price: parseFloat(row.querySelector('.price-input').value) || 0
        };
        
        if (item.description && item.quantity > 0) {
            items.push(item);
        }
    });
    
    if (items.length === 0) {
        InvoiceSystem.showToast('Please add at least one valid line item', 'danger');
        return false;
    }
    
    // Set line items data
    document.getElementById('line_items').value = JSON.stringify(items);
    
    // Show loading state
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Creating Challan...';
    submitButton.disabled = true;
    
    // Submit form
    setTimeout(() => {
        event.target.submit();
    }, 100);
}

// Validate challan form
function validateChallanForm() {
    const clientId = document.getElementById('client_id').value;
    const challanDate = document.getElementById('challan_date').value;
    
    if (!clientId) {
        InvoiceSystem.showToast('Please select a client', 'danger');
        document.getElementById('client_id').focus();
        return false;
    }
    
    if (!challanDate) {
        InvoiceSystem.showToast('Please enter challan date', 'danger');
        document.getElementById('challan_date').focus();
        return false;
    }
    
    // Validate line items
    const rows = document.querySelectorAll('#challanItemsBody tr');
    let validItems = 0;
    
    rows.forEach(row => {
        const desc = row.querySelector('.desc-input').value;
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        
        if (desc && qty > 0) {
            validItems++;
        }
    });
    
    if (validItems === 0) {
        InvoiceSystem.showToast('Please add at least one valid line item with description and quantity', 'danger');
        return false;
    }
    
    return true;
}

// Handle keyboard shortcuts
function handleChallanKeyboardShortcuts(event) {
    // Ctrl + Enter to add new line item
    if (event.ctrlKey && event.key === 'Enter') {
        event.preventDefault();
        addChallanItem();
    }
    
    // Ctrl + S to save (submit form)
    if (event.ctrlKey && event.key === 's') {
        event.preventDefault();
        const form = document.getElementById('challanForm');
        if (form) {
            form.dispatchEvent(new Event('submit'));
        }
    }
    
    // Ctrl + I to import from invoice
    if (event.ctrlKey && event.key === 'i') {
        event.preventDefault();
        showImportModal();
    }
}

// Setup client autocomplete
function setupChallanClientAutocomplete() {
    const clientSelect = document.getElementById('client_id');
    if (!clientSelect) return;
    
    // Add search functionality to select dropdown
    clientSelect.addEventListener('focus', function() {
        this.size = Math.min(this.options.length, 8);
    });
    
    clientSelect.addEventListener('blur', function() {
        this.size = 1;
    });
    
    clientSelect.addEventListener('keyup', function(event) {
        const searchTerm = event.target.value.toLowerCase();
        const options = this.options;
        
        for (let i = 0; i < options.length; i++) {
            const option = options[i];
            const text = option.text.toLowerCase();
            
            if (text.includes(searchTerm) || option.value === '') {
                option.style.display = '';
            } else {
                option.style.display = 'none';
            }
        }
    });
}

// Show import modal
function showImportModal() {
    const clientId = document.getElementById('client_id').value;
    if (!clientId) {
        InvoiceSystem.showToast('Please select a client first', 'warning');
        return;
    }
    
    const modal = new bootstrap.Modal(document.getElementById('importModal'));
    modal.show();
}

// Load client invoices for import
function loadClientInvoicesForImport(clientId) {
    const importSelect = document.getElementById('importInvoiceSelect');
    if (!importSelect) return;
    
    importSelect.innerHTML = '<option value="">Loading invoices...</option>';
    
    fetch(`/api/client/${clientId}/invoices`)
        .then(response => response.json())
        .then(data => {
            let optionsHTML = '<option value="">Choose an invoice to import items...</option>';
            
            data.invoices.forEach(invoice => {
                optionsHTML += `<option value="${invoice.id}" data-items='${JSON.stringify(invoice.line_items)}'>
                    Invoice #${invoice.invoice_number} - ₹${invoice.total_amount.toFixed(2)}
                </option>`;
            });
            
            importSelect.innerHTML = optionsHTML;
            
            // Add event listener for invoice selection
            importSelect.addEventListener('change', function() {
                if (this.value) {
                    const selectedOption = this.options[this.selectedIndex];
                    const items = JSON.parse(selectedOption.dataset.items || '[]');
                    displayInvoiceItemsForImport(items);
                } else {
                    hideInvoiceItemsForImport();
                }
            });
        })
        .catch(error => {
            console.error('Error loading invoices:', error);
            importSelect.innerHTML = '<option value="">Error loading invoices</option>';
        });
}

// Display invoice items for import
function displayInvoiceItemsForImport(items) {
    const invoiceItemsDiv = document.getElementById('invoiceItems');
    const invoiceItemsBody = document.getElementById('invoiceItemsBody');
    
    if (!invoiceItemsDiv || !invoiceItemsBody) return;
    
    let itemsHTML = '';
    items.forEach((item, index) => {
        itemsHTML += `
            <tr>
                <td>
                    <input type="checkbox" class="form-check-input import-item-checkbox" 
                           value="${index}" checked>
                </td>
                <td>${item.description}</td>
                <td>${item.hsn_code || '-'}</td>
                <td>${item.quantity}</td>
                <td>${item.unit}</td>
            </tr>
        `;
    });
    
    invoiceItemsBody.innerHTML = itemsHTML;
    invoiceItemsDiv.classList.remove('d-none');
    
    // Store items for import
    window.availableImportItems = items;
}

// Hide invoice items for import
function hideInvoiceItemsForImport() {
    const invoiceItemsDiv = document.getElementById('invoiceItems');
    if (invoiceItemsDiv) {
        invoiceItemsDiv.classList.add('d-none');
    }
}

// Confirm import
function confirmImport() {
    const checkedBoxes = document.querySelectorAll('.import-item-checkbox:checked');
    
    if (checkedBoxes.length === 0) {
        InvoiceSystem.showToast('Please select at least one item to import', 'warning');
        return;
    }
    
    const selectedItems = [];
    checkedBoxes.forEach(checkbox => {
        const index = parseInt(checkbox.value);
        if (window.availableImportItems && window.availableImportItems[index]) {
            selectedItems.push(window.availableImportItems[index]);
        }
    });
    
    // Clear existing items
    const tbody = document.getElementById('challanItemsBody');
    tbody.innerHTML = '';
    challanItemCounter = 0;
    
    // Add imported items
    selectedItems.forEach(item => {
        addImportedChallanItem(item);
    });
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('importModal'));
    modal.hide();
    
    InvoiceSystem.showToast(`${selectedItems.length} items imported successfully`, 'success');
}

// Add imported challan item
function addImportedChallanItem(item) {
    challanItemCounter++;
    const tbody = document.getElementById('challanItemsBody');
    const row = document.createElement('tr');
    row.className = 'challan-item-row';
    row.innerHTML = `
        <td>${challanItemCounter}</td>
        <td>
            <input type="text" class="form-control form-control-sm hsn-input" 
                   value="${item.hsn_code || ''}" placeholder="HSN Code">
        </td>
        <td>
            <input type="text" class="form-control form-control-sm desc-input" 
                   value="${item.description}" placeholder="Item description" required>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm qty-input" 
                   value="${item.quantity}" step="0.01" min="0" required>
        </td>
        <td>
            <select class="form-select form-select-sm unit-input">
                <option value="Nos" ${item.unit === 'Nos' ? 'selected' : ''}>Nos</option>
                <option value="Kg" ${item.unit === 'Kg' ? 'selected' : ''}>Kg</option>
                <option value="Ltr" ${item.unit === 'Ltr' ? 'selected' : ''}>Ltr</option>
                <option value="Mtr" ${item.unit === 'Mtr' ? 'selected' : ''}>Mtr</option>
                <option value="Ft" ${item.unit === 'Ft' ? 'selected' : ''}>Ft</option>
                <option value="Box" ${item.unit === 'Box' ? 'selected' : ''}>Box</option>
                <option value="Set" ${item.unit === 'Set' ? 'selected' : ''}>Set</option>
                <option value="Pair" ${item.unit === 'Pair' ? 'selected' : ''}>Pair</option>
                <option value="Pcs" ${item.unit === 'Pcs' ? 'selected' : ''}>Pcs</option>
            </select>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm price-input" 
                   value="0.00" step="0.01" min="0" placeholder="0.00">
        </td>
        <td class="total-cell text-end">₹0.00</td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeChallanItem(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    // Add event listeners to new row
    setupChallanItemEventListeners(row);
    
    // Calculate totals
    calculateChallanTotals();
}

// Preview challan
function previewChallan() {
    if (!validateChallanForm()) {
        return;
    }
    
    const challanData = collectChallanData();
    if (challanData) {
        generateChallanPreviewWindow(challanData);
    }
}

// Collect challan data for preview
function collectChallanData() {
    const clientSelect = document.getElementById('client_id');
    const selectedClient = clientSelect.options[clientSelect.selectedIndex];
    
    if (!selectedClient.value) {
        InvoiceSystem.showToast('Please select a client first', 'warning');
        return null;
    }
    
    const items = [];
    const rows = document.querySelectorAll('#challanItemsBody tr');
    
    rows.forEach(row => {
        const desc = row.querySelector('.desc-input').value;
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        
        if (desc && qty > 0) {
            items.push({
                description: desc,
                hsn_code: row.querySelector('.hsn-input').value,
                quantity: qty,
                unit: row.querySelector('.unit-input').value,
                unit_price: parseFloat(row.querySelector('.price-input').value) || 0
            });
        }
    });
    
    return {
        client: {
            name: selectedClient.dataset.name,
            address: selectedClient.dataset.address,
            city: selectedClient.dataset.city,
            state: selectedClient.dataset.state,
            phone: selectedClient.dataset.phone
        },
        challan_date: document.getElementById('challan_date').value,
        delivery_date: document.getElementById('delivery_date').value,
        transport_mode: document.getElementById('transport_mode').value,
        vehicle_number: document.getElementById('vehicle_number').value,
        notes: document.getElementById('notes').value,
        items: items
    };
}

// Generate challan preview window
function generateChallanPreviewWindow(data) {
    const previewWindow = window.open('', '_blank', 'width=800,height=600');
    const previewHTML = generateChallanPreviewHTML(data);
    
    previewWindow.document.write(previewHTML);
    previewWindow.document.close();
}

// Generate challan preview HTML
function generateChallanPreviewHTML(data) {
    let itemsHTML = '';
    let totalQuantity = 0;
    let totalValue = 0;
    
    data.items.forEach((item, index) => {
        const lineTotal = item.quantity * item.unit_price;
        totalQuantity += item.quantity;
        totalValue += lineTotal;
        
        itemsHTML += `
            <tr>
                <td>${index + 1}</td>
                <td>${item.hsn_code || ''}</td>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>${item.unit}</td>
                <td>₹${item.unit_price.toFixed(2)}</td>
                <td>₹${lineTotal.toFixed(2)}</td>
            </tr>
        `;
    });
    
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Delivery Challan Preview</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                body { font-family: Arial, sans-serif; }
                .challan-header { background: #1cc88a; color: white; padding: 1rem; }
                @media print { .no-print { display: none; } }
            </style>
        </head>
        <body>
            <div class="container mt-4">
                <div class="challan-header text-center mb-4">
                    <h2>DELIVERY CHALLAN</h2>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>To:</h6>
                        <strong>${data.client.name}</strong><br>
                        ${data.client.address || ''}<br>
                        ${data.client.city || ''}, ${data.client.state || ''}<br>
                        Phone: ${data.client.phone || 'N/A'}
                    </div>
                    <div class="col-md-6 text-end">
                        <p><strong>Challan Date:</strong> ${data.challan_date}</p>
                        <p><strong>Delivery Date:</strong> ${data.delivery_date || 'TBD'}</p>
                        <p><strong>Transport:</strong> ${data.transport_mode || 'N/A'}</p>
                        <p><strong>Vehicle:</strong> ${data.vehicle_number || 'N/A'}</p>
                    </div>
                </div>
                
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>HSN</th>
                            <th>Description</th>
                            <th>Qty</th>
                            <th>Unit</th>
                            <th>Rate</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsHTML}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"><strong>Total:</strong></td>
                            <td><strong>${totalQuantity}</strong></td>
                            <td></td>
                            <td></td>
                            <td><strong>₹${totalValue.toFixed(2)}</strong></td>
                        </tr>
                    </tfoot>
                </table>
                
                ${data.notes ? `<div class="mt-3"><strong>Notes:</strong> ${data.notes}</div>` : ''}
                
                <div class="row mt-5">
                    <div class="col-6">
                        <p>Receiver's Signature: ___________________</p>
                    </div>
                    <div class="col-6 text-end">
                        <p>For Your Company</p>
                        <br><br>
                        <p>Authorized Signatory</p>
                    </div>
                </div>
                
                <div class="no-print text-center mt-4">
                    <button class="btn btn-primary" onclick="window.print()">Print</button>
                    <button class="btn btn-secondary" onclick="window.close()">Close</button>
                </div>
            </div>
        </body>
        </html>
    `;
}

// Debounced product suggestions
let suggestionTimeout;
function debounceProductSuggestions(query) {
    clearTimeout(suggestionTimeout);
    suggestionTimeout = setTimeout(() => {
        if (query.length >= 3) {
            fetchProductSuggestions(query);
        }
    }, 300);
}

// Fetch product suggestions
function fetchProductSuggestions(query) {
    fetch(`/api/product-suggestions?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            // Could implement dropdown suggestions here
            console.log('Product suggestions:', data);
        })
        .catch(error => {
            console.error('Error fetching product suggestions:', error);
        });
}

// Make functions globally available
window.ChallanForm = {
    addChallanItem,
    removeChallanItem,
    calculateChallanTotals,
    previewChallan,
    confirmImport,
    showImportModal
};
