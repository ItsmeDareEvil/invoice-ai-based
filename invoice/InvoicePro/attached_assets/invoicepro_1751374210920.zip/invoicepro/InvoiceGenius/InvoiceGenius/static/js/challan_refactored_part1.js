// Delivery Challan Management JavaScript - Refactor Part 1

let challanItemCounter = 0;
let selectedClient = null;
let updateGenerateButtonTimeout;
let calculateTotalsTimeout;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeChallanForm();
    setupEventListeners();
});

// Initialize challan form
function initializeChallanForm() {
    const today = new Date().toISOString().split('T')[0];
    const challanDateInput = document.getElementById('challan_date');
    const deliveryDateInput = document.getElementById('delivery_date');

    if (challanDateInput && !challanDateInput.value) {
        challanDateInput.value = today;
    }

    if (deliveryDateInput && !deliveryDateInput.value && challanDateInput.value) {
        const deliveryDate = new Date(challanDateInput.value);
        deliveryDate.setDate(deliveryDate.getDate() + 1);
        deliveryDateInput.value = deliveryDate.toISOString().split('T')[0];
    }

    setupChallanClientAutocomplete();
}

// Setup all event listeners with debouncing where needed
function setupEventListeners() {
    const clientSelect = document.getElementById('client_id');
    if (clientSelect) {
        clientSelect.addEventListener('change', handleChallanClientSelection);
    }

    const challanDateInput = document.getElementById('challan_date');
    if (challanDateInput) {
        challanDateInput.addEventListener('change', updateDeliveryDate);
    }

    const challanForm = document.getElementById('challanForm');
    if (challanForm) {
        challanForm.addEventListener('submit', handleChallanFormSubmission);
    }
