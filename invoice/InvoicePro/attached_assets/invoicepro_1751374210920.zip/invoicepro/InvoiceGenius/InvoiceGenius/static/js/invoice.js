// Invoice Management - JavaScript

// Global variables
let lineItemCounter = 0;
let lineItems = [];
let selectedClient = null;
let taxRates = {
    cgst: 9,
    sgst: 9,
    igst: 18
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeInvoiceForm();
    setupEventListeners();
    addLineItem(); // Add first empty line item
});

// Initialize invoice form
function initializeInvoiceForm() {
    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    const invoiceDateInput = document.getElementById('invoice_date');
    const dueDateInput = document.getElementById('due_date');
    
    if (invoiceDateInput && !invoiceDateInput.value) {
        invoiceDateInput.value = today;
    }
    
    // Set default due date (30 days from invoice date)
    if (dueDateInput && !dueDateInput.value && invoiceDateInput.value) {
        const invoiceDate = new Date(invoiceDateInput.value);
        invoiceDate.setDate(invoiceDate.getDate() + 30);
        dueDateInput.value = invoiceDate.toISOString().split('T')[0];
    }
    
    // Setup client autocomplete
    setupClientAutocomplete();
}

// Setup event listeners
function setupEventListeners() {
    // Client selection
    const clientSelect = document.getElementById('client_id');
    if (clientSelect) {
        clientSelect.addEventListener('change', handleClientSelection);
    }
    
    // Invoice date change
    const invoiceDateInput = document.getElementById('invoice_date');
    if (invoiceDateInput) {
        invoiceDateInput.addEventListener('change', updateDueDate);
    }
    
    // Form submission
    const invoiceForm = document.getElementById('invoiceForm');
    if (invoiceForm) {
        invoiceForm.addEventListener('submit', handleFormSubmission);
    }
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
}

// Handle client selection
function handleClientSelection(event) {
    const selectedOption = event.target.options[event.target.selectedIndex];
    const clientDetails = document.getElementById('clientDetails');
    
    if (selectedOption.value) {
        // Populate client details
        document.getElementById('clientAddress').textContent = selectedOption.dataset.address || 'N/A';
        document.getElementById('clientCity').textContent = selectedOption.dataset.city || 'N/A';
        document.getElementById('clientState').textContent = selectedOption.dataset.state || 'N/A';
        document.getElementById('clientGstin').textContent = selectedOption.dataset.gstin || 'N/A';
        document.getElementById('clientPhone').textContent = selectedOption.dataset.phone || 'N/A';
        document.getElementById('clientEmail').textContent = selectedOption.dataset.email || 'N/A';
        
        clientDetails.classList.remove('d-none');
        
        // Store selected client data
        selectedClient = {
            id: selectedOption.value,
            name: selectedOption.dataset.name,
            state: selectedOption.dataset.state,
            gstin: selectedOption.dataset.gstin
        };
        
        // Update tax calculation based on client state
        updateTaxRates();
        calculateTotals();
    } else {
        clientDetails.classList.add('d-none');
        selectedClient = null;
    }
}

// Update due date based on invoice date
function updateDueDate() {
    const invoiceDateInput = document.getElementById('invoice_date');
    const dueDateInput = document.getElementById('due_date');
    
    if (invoiceDateInput.value && dueDateInput && !dueDateInput.value) {
        const invoiceDate = new Date(invoiceDateInput.value);
        invoiceDate.setDate(invoiceDate.getDate() + 30);
        dueDateInput.value = invoiceDate.toISOString().split('T')[0];
    }
}

// Update tax rates based on client state
function updateTaxRates() {
    // This would typically fetch company state from server
    const companyState = 'Tamil Nadu'; // Default company state
    
    if (selectedClient && selectedClient.state === companyState) {
        // Same state - CGST + SGST
        taxRates = { cgst: 9, sgst: 9, igst: 0 };
    } else {
        // Different state - IGST
        taxRates = { cgst: 0, sgst: 0, igst: 18 };
    }
}

// Add line item
function addLineItem() {
    lineItemCounter++;
    const tbody = document.getElementById('lineItemsBody');
    const row = document.createElement('tr');
    row.className = 'invoice-item-row';
    row.innerHTML = `
        <td>${lineItemCounter}</td>
        <td>
            <input type="text" class="form-control form-control-sm hsn-input" 
                   placeholder="HSN Code" data-bs-toggle="tooltip" title="Harmonized System of Nomenclature Code">
        </td>
        <td>
            <input type="text" class="form-control form-control-sm desc-input" 
                   placeholder="Item description" required>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm qty-input" 
                   step="0.01" min="0" placeholder="1" required>
        </td>
        <td>
            <select class="form-select form-select-sm unit-input">
                <option value="Nos">Nos</option>
                <option value="Kg">Kg</option>
                <option value="Ltr">Ltr</option>
                <option value="Mtr">Mtr</option>
                <option value="Ft">Ft</option>
                <option value="Box">Box</option>
                <option value="Set">Set</option>
                <option value="Pair">Pair</option>
            </select>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm price-input" 
                   step="0.01" min="0" placeholder="0.00" required>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm tax-input" 
                   step="0.01" min="0" max="100" value="18" placeholder="18">
        </td>
        <td>
            <input type="number" class="form-control form-control-sm cost-input" 
                   step="0.01" min="0" placeholder="0.00" 
                   data-bs-toggle="tooltip" title="Cost price for profit calculation">
        </td>
        <td class="total-cell text-end">₹0.00</td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeLineItem(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    // Add event listeners to new row
    setupLineItemEventListeners(row);
    
    // Initialize tooltips for new elements
    const tooltips = row.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(element => {
        new bootstrap.Tooltip(element);
    });
    
    // Focus on description input
    row.querySelector('.desc-input').focus();
}

// Setup event listeners for line item row
function setupLineItemEventListeners(row) {
    const qtyInput = row.querySelector('.qty-input');
    const priceInput = row.querySelector('.price-input');
    const taxInput = row.querySelector('.tax-input');
    const costInput = row.querySelector('.cost-input');
    
    [qtyInput, priceInput, taxInput, costInput].forEach(input => {
        input.addEventListener('input', calculateTotals);
        input.addEventListener('blur', calculateTotals);
    });
    
    // HSN code autocomplete
    const hsnInput = row.querySelector('.hsn-input');
    hsnInput.addEventListener('input', function() {
        // You could implement HSN code suggestions here
        if (this.value.length >= 4) {
            // Trigger HSN code validation or suggestions
        }
    });
    
    // Description autocomplete
    const descInput = row.querySelector('.desc-input');
    descInput.addEventListener('input', function() {
        // You could implement product description suggestions here
    });
}

// Remove line item
function removeLineItem(button) {
    const row = button.closest('tr');
    row.remove();
    calculateTotals();
    renumberLineItems();
}

// Renumber line items
function renumberLineItems() {
    const rows = document.querySelectorAll('#lineItemsBody tr');
    rows.forEach((row, index) => {
        row.querySelector('td:first-child').textContent = index + 1;
    });
    lineItemCounter = rows.length;
}

// Calculate totals
function calculateTotals() {
    let subtotal = 0;
    let totalCgst = 0;
    let totalSgst = 0;
    let totalIgst = 0;
    
    const rows = document.querySelectorAll('#lineItemsBody tr');
    
    rows.forEach(row => {
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        const taxPercent = parseFloat(row.querySelector('.tax-input').value) || 0;
        
        const lineTotal = qty * price;
        const taxAmount = (lineTotal * taxPercent) / 100;
        const lineGrandTotal = lineTotal + taxAmount;
        
        // Update line total display
        row.querySelector('.total-cell').textContent = `₹${lineGrandTotal.toFixed(2)}`;
        
        subtotal += lineTotal;
        
        // Calculate tax based on client state
        /* if (selectedClient && taxRates.igst === 0) {
            // Same state - CGST + SGST
            totalCgst += taxAmount / 2;
            totalSgst += taxAmount / 2;
        } else {
            // Different state - IGST
            totalIgst += taxAmount;
        } */
        totalCgst += taxAmount / 2;
        totalSgst += taxAmount / 2;

    });
    
    const grandTotal = subtotal + totalCgst + totalSgst + totalIgst;
    
    // Update display
    document.getElementById('subtotalAmount').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('cgstAmount').textContent = `₹${totalCgst.toFixed(2)}`;
    document.getElementById('sgstAmount').textContent = `₹${totalSgst.toFixed(2)}`;
    document.getElementById('igstAmount').textContent = `₹${totalIgst.toFixed(2)}`;
    document.getElementById('grandTotal').textContent = `₹${grandTotal.toFixed(2)}`;
    
    // Update amount in words
    updateAmountInWords(grandTotal);
}

// Update amount in words
function updateAmountInWords(amount) {
    const amountInWords = numberToWords(Math.floor(amount));
    const amountWordsElement = document.getElementById('amountInWords');
    if (amountWordsElement) {
        amountWordsElement.textContent = `${amountInWords} Rupees Only`;
    }
}

// Convert number to words (simplified version)
function numberToWords(num) {
    if (num === 0) return 'Zero';
    
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
    const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    
    function convertHundreds(n) {
        let result = '';
        if (n >= 100) {
            result += ones[Math.floor(n / 100)] + ' Hundred ';
            n %= 100;
        }
        if (n >= 20) {
            result += tens[Math.floor(n / 10)] + ' ';
            n %= 10;
        } else if (n >= 10) {
            result += teens[n - 10] + ' ';
            n = 0;
        }
        if (n > 0) {
            result += ones[n] + ' ';
        }
        return result;
    }
    
    let result = '';
    if (num >= 10000000) {
        result += convertHundreds(Math.floor(num / 10000000)) + 'Crore ';
        num %= 10000000;
    }
    if (num >= 100000) {
        result += convertHundreds(Math.floor(num / 100000)) + 'Lakh ';
        num %= 100000;
    }
    if (num >= 1000) {
        result += convertHundreds(Math.floor(num / 1000)) + 'Thousand ';
        num %= 1000;
    }
    if (num > 0) {
        result += convertHundreds(num);
    }
    
    return result.trim();
}

// Handle form submission
function handleFormSubmission(event) {
    event.preventDefault();
    
    // Validate form
    if (!validateInvoiceForm()) {
        return false;
    }
    
    // Collect line items data
    const items = [];
    const rows = document.querySelectorAll('#lineItemsBody tr');
    
    rows.forEach((row, index) => {
        const item = {
            sr_no: index + 1,
            hsn_code: row.querySelector('.hsn-input').value,
            description: row.querySelector('.desc-input').value,
            quantity: parseFloat(row.querySelector('.qty-input').value) || 0,
            unit: row.querySelector('.unit-input').value,
            unit_price: parseFloat(row.querySelector('.price-input').value) || 0,
            tax_percentage: parseFloat(row.querySelector('.tax-input').value) || 0,
            cost_price: parseFloat(row.querySelector('.cost-input').value) || 0
        };
        
        if (item.description && item.quantity > 0 && item.unit_price > 0) {
            items.push(item);
        }
    });
    
    if (items.length === 0) {
        InvoiceSystem.showToast('Please add at least one valid line item', 'danger');
        return false;
    }
    
    // Set line items data
    document.getElementById('line_items').value = JSON.stringify(items);
    
    // Show loading state
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Creating Invoice...';
    submitButton.disabled = true;
    
    // Submit form
    setTimeout(() => {
        event.target.submit();
    }, 100);
}

// Validate invoice form
function validateInvoiceForm() {
    const clientId = document.getElementById('client_id').value;
    const invoiceDate = document.getElementById('invoice_date').value;
    
    if (!clientId) {
        InvoiceSystem.showToast('Please select a client', 'danger');
        document.getElementById('client_id').focus();
        return false;
    }
    
    if (!invoiceDate) {
        InvoiceSystem.showToast('Please enter invoice date', 'danger');
        document.getElementById('invoice_date').focus();
        return false;
    }
    
    // Validate line items
    const rows = document.querySelectorAll('#lineItemsBody tr');
    let validItems = 0;
    
    rows.forEach(row => {
        const desc = row.querySelector('.desc-input').value;
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        
        if (desc && qty > 0 && price > 0) {
            validItems++;
        }
    });
    
    if (validItems === 0) {
        InvoiceSystem.showToast('Please add at least one valid line item with description, quantity, and price', 'danger');
        return false;
    }
    
    return true;
}

// Handle keyboard shortcuts
function handleKeyboardShortcuts(event) {
    // Ctrl + Enter to add new line item
    if (event.ctrlKey && event.key === 'Enter') {
        event.preventDefault();
        addLineItem();
    }
    
    // Ctrl + S to save (submit form)
    if (event.ctrlKey && event.key === 's') {
        event.preventDefault();
        const form = document.getElementById('invoiceForm');
        if (form) {
            form.dispatchEvent(new Event('submit'));
        }
    }
    
    // Escape to cancel/go back
    if (event.key === 'Escape') {
        if (confirm('Are you sure you want to leave this page? Unsaved changes will be lost.')) {
            window.history.back();
        }
    }
}

// Setup client autocomplete
function setupClientAutocomplete() {
    const clientSelect = document.getElementById('client_id');
    if (!clientSelect) return;
    
    // Add search functionality to select dropdown
    clientSelect.addEventListener('focus', function() {
        this.size = Math.min(this.options.length, 8);
    });
    
    clientSelect.addEventListener('blur', function() {
        this.size = 1;
    });
    
    clientSelect.addEventListener('keyup', function(event) {
        const searchTerm = event.target.value.toLowerCase();
        const options = this.options;
        
        for (let i = 0; i < options.length; i++) {
            const option = options[i];
            const text = option.text.toLowerCase();
            
            if (text.includes(searchTerm) || option.value === '') {
                option.style.display = '';
            } else {
                option.style.display = 'none';
            }
        }
    });
}

// Import from template
function importFromTemplate(templateId) {
    // This would load predefined templates
    InvoiceSystem.showToast('Template import functionality would be implemented here', 'info');
}

// Save as draft
function saveAsDraft() {
    const formData = new FormData(document.getElementById('invoiceForm'));
    const draftData = {};
    
    for (let [key, value] of formData.entries()) {
        draftData[key] = value;
    }
    
    // Save to localStorage
    InvoiceSystem.setLocalStorage('invoice_draft', draftData);
    InvoiceSystem.showToast('Invoice saved as draft', 'success');
}

// Load draft
function loadDraft() {
    const draftData = InvoiceSystem.getLocalStorage('invoice_draft');
    
    if (draftData) {
        // Populate form with draft data
        Object.keys(draftData).forEach(key => {
            const element = document.querySelector(`[name="${key}"]`);
            if (element) {
                element.value = draftData[key];
            }
        });
        
        InvoiceSystem.showToast('Draft loaded', 'success');
    } else {
        InvoiceSystem.showToast('No draft found', 'info');
    }
}

// Print preview
function printPreview() {
    // Generate preview and print
    const invoiceData = collectInvoiceData();
    if (invoiceData) {
        generatePreviewWindow(invoiceData);
    }
}

// Collect invoice data for preview
function collectInvoiceData() {
    const clientSelect = document.getElementById('client_id');
    const selectedClient = clientSelect.options[clientSelect.selectedIndex];
    
    if (!selectedClient.value) {
        InvoiceSystem.showToast('Please select a client first', 'warning');
        return null;
    }
    
    const items = [];
    const rows = document.querySelectorAll('#lineItemsBody tr');
    
    rows.forEach(row => {
        const desc = row.querySelector('.desc-input').value;
        const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
        const price = parseFloat(row.querySelector('.price-input').value) || 0;
        
        if (desc && qty > 0 && price > 0) {
            items.push({
                description: desc,
                hsn_code: row.querySelector('.hsn-input').value,
                quantity: qty,
                unit: row.querySelector('.unit-input').value,
                unit_price: price,
                tax_percentage: parseFloat(row.querySelector('.tax-input').value) || 0
            });
        }
    });
    
    return {
        client: {
            name: selectedClient.dataset.name,
            address: selectedClient.dataset.address,
            city: selectedClient.dataset.city,
            state: selectedClient.dataset.state,
            gstin: selectedClient.dataset.gstin
        },
        invoice_date: document.getElementById('invoice_date').value,
        due_date: document.getElementById('due_date').value,
        notes: document.getElementById('notes').value,
        items: items
    };
}

// Generate preview window
function generatePreviewWindow(data) {
    const previewWindow = window.open('', '_blank', 'width=800,height=600');
    const previewHTML = generateInvoicePreviewHTML(data);
    
    previewWindow.document.write(previewHTML);
    previewWindow.document.close();
}

// Generate invoice preview HTML
function generateInvoicePreviewHTML(data) {
    let itemsHTML = '';
    let subtotal = 0;
    
    data.items.forEach((item, index) => {
        const lineTotal = item.quantity * item.unit_price;
        const taxAmount = (lineTotal * item.tax_percentage) / 100;
        const total = lineTotal + taxAmount;
        subtotal += lineTotal;
        
        itemsHTML += `
            <tr>
                <td>${index + 1}</td>
                <td>${item.hsn_code || ''}</td>
                <td>${item.description}</td>
                <td>${item.quantity} ${item.unit}</td>
                <td>₹${item.unit_price.toFixed(2)}</td>
                <td>${item.tax_percentage}%</td>
                <td>₹${total.toFixed(2)}</td>
            </tr>
        `;
    });
    
    const taxTotal = subtotal * 0.18; // Simplified tax calculation
    const grandTotal = subtotal + taxTotal;
    
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Invoice Preview</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                body { font-family: Arial, sans-serif; }
                .invoice-header { background: #4e73df; color: white; padding: 1rem; }
                @media print { .no-print { display: none; } }
            </style>
        </head>
        <body>
            <div class="container mt-4">
                <div class="invoice-header text-center mb-4">
                    <h2>PROFORMA INVOICE</h2>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6>Bill To:</h6>
                        <strong>${data.client.name}</strong><br>
                        ${data.client.address || ''}<br>
                        ${data.client.city || ''}, ${data.client.state || ''}<br>
                        GSTIN: ${data.client.gstin || 'N/A'}
                    </div>
                    <div class="col-md-6 text-end">
                        <p><strong>Date:</strong> ${data.invoice_date}</p>
                        <p><strong>Due Date:</strong> ${data.due_date}</p>
                    </div>
                </div>
                
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>HSN</th>
                            <th>Description</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Tax</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsHTML}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="6"><strong>Subtotal:</strong></td>
                            <td><strong>₹${subtotal.toFixed(2)}</strong></td>
                        </tr>
                        <tr>
                            <td colspan="6"><strong>Tax:</strong></td>
                            <td><strong>₹${taxTotal.toFixed(2)}</strong></td>
                        </tr>
                        <tr class="table-primary">
                            <td colspan="6"><strong>Grand Total:</strong></td>
                            <td><strong>₹${grandTotal.toFixed(2)}</strong></td>
                        </tr>
                    </tfoot>
                </table>
                
                <div class="no-print text-center mt-4">
                    <button class="btn btn-primary" onclick="window.print()">Print</button>
                    <button class="btn btn-secondary" onclick="window.close()">Close</button>
                </div>
            </div>
        </body>
        </html>
    `;
}

// Make functions globally available
window.InvoiceForm = {
    addLineItem,
    removeLineItem,
    calculateTotals,
    saveAsDraft,
    loadDraft,
    printPreview,
    importFromTemplate
};
