// Dashboard JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    loadDashboardData();
    setupDashboardEventListeners();
});

// Initialize dashboard
function initializeDashboard() {
    // Setup refresh functionality
    setupAutoRefresh();
    
    // Initialize charts if data is available
    if (typeof monthlyRevenueData !== 'undefined') {
        initializeRevenueChart();
    }
    
    // Setup quick action shortcuts
    setupQuickActions();
}

// Load dashboard data
function loadDashboardData() {
    // Refresh stats cards
    refreshStatsCards();
    
    // Load recent activities
    loadRecentActivities();
    
    // Load notifications
    loadNotifications();
}

// Setup dashboard event listeners
function setupDashboardEventListeners() {
    // Refresh button
    const refreshBtn = document.getElementById('refreshDashboard');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshDashboard();
        });
    }
    
    // Quick action buttons
    const quickActions = document.querySelectorAll('.quick-action-btn');
    quickActions.forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.dataset.action;
            handleQuickAction(action);
        });
    });
    
    // Chart period selector
    const periodSelector = document.getElementById('chartPeriod');
    if (periodSelector) {
        periodSelector.addEventListener('change', function() {
            updateChartPeriod(this.value);
        });
    }
}

// Initialize revenue chart
function initializeRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;
    
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: monthNames,
            datasets: [{
                label: 'Monthly Revenue',
                data: monthlyRevenueData.map(item => item.revenue),
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#4e73df',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#4e73df',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return 'Revenue: ₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            },
            animation: {
                duration: 2000,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// Setup auto refresh
function setupAutoRefresh() {
    // Refresh dashboard every 5 minutes
    setInterval(function() {
        refreshDashboard(false); // Silent refresh
    }, 5 * 60 * 1000);
}

// Refresh dashboard
function refreshDashboard(showNotification = true) {
    if (showNotification) {
        InvoiceSystem.showToast('Refreshing dashboard...', 'info');
    }
    
    // Refresh stats
    refreshStatsCards();
    
    // Refresh recent activities
    loadRecentActivities();
    
    // Refresh chart data
    refreshChartData();
    
    if (showNotification) {
        setTimeout(() => {
            InvoiceSystem.showToast('Dashboard refreshed', 'success');
        }, 1000);
    }
}

// Refresh stats cards
function refreshStatsCards() {
    fetch('/api/dashboard/stats')
        .then(response => response.json())
        .then(data => {
            updateStatsCards(data);
        })
        .catch(error => {
            console.error('Error refreshing stats:', error);
        });
}

// Update stats cards
function updateStatsCards(data) {
    const cards = {
        'total-revenue': data.total_revenue,
        'outstanding-amount': data.outstanding_amount,
        'total-invoices': data.total_invoices,
        'total-clients': data.total_clients
    };
    
    Object.keys(cards).forEach(cardId => {
        const element = document.querySelector(`[data-stat="${cardId}"]`);
        if (element) {
            if (cardId.includes('revenue') || cardId.includes('amount')) {
                element.textContent = formatCurrency(cards[cardId]);
            } else {
                element.textContent = cards[cardId];
            }
            
            // Add animation effect
            element.classList.add('stat-updated');
            setTimeout(() => {
                element.classList.remove('stat-updated');
            }, 1000);
        }
    });
}

// Load recent activities
function loadRecentActivities() {
    fetch('/api/dashboard/recent-activities')
        .then(response => response.json())
        .then(data => {
            updateRecentActivities(data);
        })
        .catch(error => {
            console.error('Error loading recent activities:', error);
        });
}

// Update recent activities
function updateRecentActivities(activities) {
    const container = document.getElementById('recentActivitiesContainer');
    if (!container) return;
    
    if (activities.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">No recent activities</p>';
        return;
    }
    
    let html = '';
    activities.forEach(activity => {
        html += `
            <div class="activity-item border-bottom py-2">
                <div class="d-flex align-items-center">
                    <div class="activity-icon me-3">
                        <i class="fas fa-${activity.icon} text-${activity.type}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="activity-text">${activity.message}</div>
                        <small class="text-muted">${activity.timestamp}</small>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Load notifications
function loadNotifications() {
    fetch('/api/dashboard/notifications')
        .then(response => response.json())
        .then(data => {
            updateNotifications(data);
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
        });
}

// Update notifications
function updateNotifications(notifications) {
    const container = document.getElementById('notificationsContainer');
    if (!container) return;
    
    // Update notification badge
    const badge = document.getElementById('notificationBadge');
    if (badge) {
        if (notifications.length > 0) {
            badge.textContent = notifications.length;
            badge.style.display = 'inline';
        } else {
            badge.style.display = 'none';
        }
    }
    
    // Update notification list
    if (notifications.length === 0) {
        container.innerHTML = '<p class="text-muted text-center">No new notifications</p>';
        return;
    }
    
    let html = '';
    notifications.forEach(notification => {
        html += `
            <div class="notification-item alert alert-${notification.type} alert-dismissible fade show" role="alert">
                <strong>${notification.title}</strong> ${notification.message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Setup quick actions
function setupQuickActions() {
    const quickActions = [
        { key: 'i', action: 'create-invoice', element: 'a[href*="create_invoice"]' },
        { key: 'c', action: 'create-client', element: 'a[href*="create_client"]' },
        { key: 'd', action: 'create-challan', element: 'a[href*="create_challan"]' },
        { key: 'r', action: 'view-reports', element: 'a[href*="reports"]' }
    ];
    
    document.addEventListener('keydown', function(event) {
        // Only trigger if Ctrl/Cmd is pressed
        if (event.ctrlKey || event.metaKey) {
            const action = quickActions.find(qa => qa.key === event.key.toLowerCase());
            if (action) {
                event.preventDefault();
                const element = document.querySelector(action.element);
                if (element) {
                    element.click();
                }
            }
        }
    });
}

// Handle quick actions
function handleQuickAction(action) {
    switch (action) {
        case 'create-invoice':
            window.location.href = '/create_invoice';
            break;
        case 'create-client':
            window.location.href = '/create_client';
            break;
        case 'create-challan':
            window.location.href = '/create_challan';
            break;
        case 'view-reports':
            window.location.href = '/reports';
            break;
        case 'export-data':
            exportDashboardData();
            break;
        case 'backup-database':
            backupDatabase();
            break;
        default:
            console.log('Unknown action:', action);
    }
}

// Update chart period
function updateChartPeriod(period) {
    fetch(`/api/dashboard/chart-data?period=${period}`)
        .then(response => response.json())
        .then(data => {
            updateChartData(data);
        })
        .catch(error => {
            console.error('Error updating chart period:', error);
        });
}

// Refresh chart data
function refreshChartData() {
    const periodSelector = document.getElementById('chartPeriod');
    const period = periodSelector ? periodSelector.value : 'monthly';
    
    fetch(`/api/dashboard/chart-data?period=${period}`)
        .then(response => response.json())
        .then(data => {
            updateChartData(data);
        })
        .catch(error => {
            console.error('Error refreshing chart data:', error);
        });
}

// Update chart data
function updateChartData(data) {
    const chart = Chart.getChart('revenueChart');
    if (chart) {
        chart.data.datasets[0].data = data.map(item => item.revenue);
        chart.update('active');
    }
}

// Export dashboard data
function exportDashboardData() {
    InvoiceSystem.showToast('Exporting dashboard data...', 'info');
    
    fetch('/api/dashboard/export', {
        method: 'POST'
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `dashboard-export-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
        InvoiceSystem.showToast('Dashboard data exported successfully', 'success');
    })
    .catch(error => {
        console.error('Error exporting dashboard data:', error);
        InvoiceSystem.showToast('Failed to export dashboard data', 'danger');
    });
}

// Backup database
function backupDatabase() {
    if (confirm('This will create a backup of your entire database. Continue?')) {
        InvoiceSystem.showToast('Creating database backup...', 'info');
        
        fetch('/api/backup-database', {
            method: 'POST'
        })
        .then(response => response.blob())
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `invoice-backup-${new Date().toISOString().split('T')[0]}.db`;
            a.click();
            window.URL.revokeObjectURL(url);
            InvoiceSystem.showToast('Database backup completed', 'success');
        })
        .catch(error => {
            console.error('Error creating backup:', error);
            InvoiceSystem.showToast('Failed to create backup', 'danger');
        });
    }
}

// Format currency for display
function formatCurrency(amount) {
    return '₹' + parseFloat(amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Animation for stat updates
const style = document.createElement('style');
style.textContent = `
    .stat-updated {
        animation: statPulse 1s ease-in-out;
    }
    
    @keyframes statPulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); color: #4e73df; }
        100% { transform: scale(1); }
    }
    
    .activity-item {
        transition: background-color 0.3s ease;
    }
    
    .activity-item:hover {
        background-color: rgba(78, 115, 223, 0.1);
    }
    
    .activity-icon {
        width: 30px;
        text-align: center;
    }
`;
document.head.appendChild(style);

// Make functions globally available
window.Dashboard = {
    refreshDashboard,
    exportDashboardData,
    backupDatabase,
    handleQuickAction
};
